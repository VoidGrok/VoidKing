# VoidKing UI

UI Library para Roblox (baseada no CompKiller)

## Como usar

```lua
local VoidKing = loadstring(game:HttpGet("SUA_URL_AQUI/source.luau"))()

VoidKing:Loader(nil, 1.5).yield()

local Window = VoidKing.new({
	Name = "VoidKing",
	Keybind = "LeftAlt",
	Logo = "rbxassetid://120245531583106",
	-- Scale = VoidKing.Scale.Window, -- 615x344
	-- Scale = VoidKing.Scale.Mobile, -- menor pro celular
})
```

## Temas disponiveis

Use:

```lua
VoidKing:SetTheme("Vermelho")
VoidKing:SetTheme("Azul")
VoidKing:SetTheme("Verde")
VoidKing:SetTheme("Roxo")
-- etc
```

Lista completa:
Default, Dark Green, Dark Blue, Purple Rose, Skeet,
Branco, Preto, Cinza, Prata,
Vermelho, Vermelho Claro, Vermelho Escuro, Vermelho Tomate, Coral, Salmao,
Azul, Azul Claro, Azul Escuro, Azul Marinho, Azul Aco, Azul Celeste, Indigo,
Verde, Verde Claro, Verde Escuro, Verde Agua, Verde Musgo, Verde Primavera, Lima, Turquesa, Verde Oliva,
Amarelo, Amarelo Claro, Amarelo Ouro, Ouro,
Roxo, Roxo Claro, Roxo Escuro, Violeta, Orquidea, Lavanda, Magenta,
Laranja, Laranja Claro, Laranja Escuro, Laranja Queimado,
Rosa, Rosa Claro, Rosa Escuro, Pessego,
Marrom, Marrom Chocolate, Bronze, Bege, Caqui

## Fonte

```lua
VoidKing:SetFont(Enum.Font.GothamBold)
-- ou
VoidKing:SetFont("GothamMedium")
```

Fontes comuns: GothamMedium, GothamBold, SourceSans, Roboto, Ubuntu, Code, etc.

## Tamanhos

- PC: 615 x 344
- Mobile: 360 x 280
- Sidebar aberta: 150px

## Icones

Usa icones estilo Lucide (https://lucide.dev).

```lua
VoidKing:_GetIcon("skull")
VoidKing:_GetIcon("settings")
VoidKing:_GetIcon("eye")
```

## Observacao

O codigo foi organizado e renomeado para VoidKing.
Comentarios em portugues simples.
